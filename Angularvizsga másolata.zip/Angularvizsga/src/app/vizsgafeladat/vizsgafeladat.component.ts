import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})
export class VizsgafeladatComponent {
  html:number=1;
  bootstrap:number=1;
  js:number=1;
  ts:number=1;
  angular:number=1;
  szerver:number=1;

  EredmenyMentes():void{
    if(this.html==null || this.bootstrap==null || this.js==null || this.ts==null || this.angular==null || this.szerver==null){
      alert("Az összes mező kitöltése kötelező!")
    }
    else{
      if((this.html+this.bootstrap+this.js+this.ts+this.angular+this.szerver)<50){
        this.korabbiEredmenyek.push(`Sikertelen vizsga, szerzett pont: ${this.html+this.bootstrap+this.js+this.ts+this.angular+this.szerver}`)
      }
      else if((this.html+this.bootstrap+this.js+this.ts+this.angular+this.szerver)<60){
        this.korabbiEredmenyek.push(`Sikeres vizsga (2-es), szerzett pont: ${this.html+this.bootstrap+this.js+this.ts+this.angular+this.szerver}`)
      }
      else if((this.html+this.bootstrap+this.js+this.ts+this.angular+this.szerver)<70){
        this.korabbiEredmenyek.push(`Sikeres vizsga (3-as), szerzett pont: ${this.html+this.bootstrap+this.js+this.ts+this.angular+this.szerver}`)
      }
      else if((this.html+this.bootstrap+this.js+this.ts+this.angular+this.szerver)<80){
        this.korabbiEredmenyek.push(`Sikeres vizsga (4-es), szerzett pont: ${this.html+this.bootstrap+this.js+this.ts+this.angular+this.szerver}`)
      }
      else if((this.html+this.bootstrap+this.js+this.ts+this.angular+this.szerver)<101){
        this.korabbiEredmenyek.push(`Sikeres vizsga (5-os), szerzett pont: ${this.html+this.bootstrap+this.js+this.ts+this.angular+this.szerver}`)
      }
      else{}
    }
  }

  korabbiEredmenyek:string[]=[]
}
